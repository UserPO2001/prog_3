import tkinter as tk
from tkinter import messagebox

class DistanceCalculator(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)  # Initialize the parent class (tk.Frame)
        self.controller = controller  # Reference to the main controller (MainApp)

        # Label for the title of the frame
        label = tk.Label(self, text="Distance Calculator", font=("Helvetica", 18, "bold"))
        label.pack(side="top", fill="x", pady=20)  # Pack the label at the top, fill horizontally, and add vertical padding

        # Button to go back to the home screen
        back_button = tk.Button(self, text="Back to Home", command=lambda: controller.show_frame("StartScreen"))
        back_button.pack(pady=10)  # Pack the button with vertical padding

        # Label for the distance input field
        self.distance_label = tk.Label(self, text="Distance (km):")
        self.distance_label.pack(pady=5)  # Pack the label with vertical padding
        
        # Entry field for the distance input
        self.distance_entry = tk.Entry(self)
        self.distance_entry.pack(pady=5)  # Pack the entry field with vertical padding

        # Label for the speed entry field
        self.speed_label = tk.Label(self, text="Speed (km/h):")
        self.speed_label.pack(pady=5)  # Pack the label with vertical padding
        
        # Entry field for the speed input
        self.speed_entry = tk.Entry(self)
        self.speed_entry.pack(pady=5)  # Pack the entry field with vertical padding

        # Button to trigger the calculation
        self.calculate_button = tk.Button(self, text="Calculate", command=self.calculate_time)
        self.calculate_button.pack(pady=5)  # Pack the button with vertical padding

        # Label to display the result
        self.result_label = tk.Label(self, text="")
        self.result_label.pack(pady=5)  # Pack the label with vertical padding

    def calculate_time(self):
        try:
            # Replace commas with periods and convert inputs to float
            distance = float(self.distance_entry.get().replace(',', '.'))
            speed = float(self.speed_entry.get().replace(',', '.'))
            
            # Check if inputs are valid
            if distance < 0 or speed <= 0:
                raise ValueError

            # Calculate time
            time = distance / speed
            hours = int(time)
            minutes = int((time - hours) * 60)
            seconds = int(((time - hours) * 60 - minutes) * 60)

            # Display the result
            self.result_label.config(text=f"Travel time: {hours} hours, {minutes} minutes, and {seconds} seconds")
        
        except ValueError:
            # Show an error message if inputs are invalid
            messagebox.showerror("Invalid Input", "Please enter valid positive numbers for distance and speed.")
