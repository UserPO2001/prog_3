import tkinter as tk # Import the tkinter module for GUI creation
# import all the games
from keno_game import KenoGame
from distance_calculator import DistanceCalculator
from time_shower import TimeShower
from color_changer import ColorChangerApp

class MainApp(tk.Tk):
    def __init__(self): # setup/defining function, makes the object itself ready for use.
        super().__init__() # This line calls the setup function of the parent class (tk.Tk )
        self.title("Multi-Tool Application") # title setup
        self.geometry("800x600") # size setup

        self.frames = {} # Dictionary to hold references to all the frames


        # Container frame
        container = tk.Frame(self)  # Create a frame widget to act as a container for other frames.
        container.pack(side="top", fill="both", expand=True)  # Pack the frame to the top, make it fill the entire window, and allow it to expand with the window size
        container.grid_rowconfigure(0, weight=1)  # Configure the grid layout to make row 0 expandable, ensuring it stretches to fill available space
        container.grid_columnconfigure(0, weight=1)  # Configure the grid layout to make column 0 expandable, ensuring it stretches to fill available space


        # Create frames for each application
        for F in (StartScreen, KenoGame, DistanceCalculator, TimeShower, ColorChangerApp):
            page_name = F.__name__  # Get the class name as a string
            frame = F(parent=container, controller=self)  # Create an instance of the frame
            self.frames[page_name] = frame  # Add the frame to the frames dictionary
            frame.grid(row=0, column=0, sticky="nsew")  # Add the frame to the container using grid

        # Show the StartScreen initially
        self.show_frame("StartScreen")

    def show_frame(self, page_name):
        """Raise the frame with the given name."""
        frame = self.frames[page_name]
        frame.tkraise()

class StartScreen(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.setup_ui()

    def setup_ui(self):
        label = tk.Label(self, text="Select a Tool", font=("Helvetica", 24, "bold"))
        label.pack(side="top", fill="x", pady=20)

        # Buttons to navigate to each tool
        buttons = [
            ("Keno Game", "KenoGame"),
            ("Distance Calculator", "DistanceCalculator"),
            ("Time Shower", "TimeShower"),
            ("Colour Changer", "ColorChangerApp")
        ]

        for text, page_name in buttons:
            button = tk.Button(self, text=text, command=lambda name=page_name: self.controller.show_frame(name), font=("Helvetica", 16))
            button.pack(pady=10, padx=20, fill="x")

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
