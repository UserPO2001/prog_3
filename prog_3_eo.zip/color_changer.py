import tkinter as tk
from tkinter import colorchooser

class ColorChangerApp(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        label = tk.Label(self, text="Color Changer", font=("Helvetica", 18, "bold"))
        label.pack(side="top", fill="x", pady=20)

        back_button = tk.Button(self, text="Back to Home", command=lambda: controller.show_frame("StartScreen"))
        back_button.pack(pady=10)

        self.title_label = tk.Label(self, text="Lorem ipsum", font=("Helvetica", 32))
        self.title_label.pack(pady=10)

        self.color_square = tk.Label(self, width=20, height=10, bg="black")
        self.color_square.pack(pady=10)

        self.font_color_button = tk.Button(self, text="Change Font Color", command=self.change_font_color)
        self.font_color_button.pack(pady=10)

        self.bg_color_button = tk.Button(self, text="Change Background Color", command=self.change_bg_color)
        self.bg_color_button.pack(pady=10)

    def change_font_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.title_label.config(fg=color)
            self.color_square.config(bg=color)

    def change_bg_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.config(bg=color)
            self.title_label.config(bg=color)
            self.color_square.config(bg=color)
