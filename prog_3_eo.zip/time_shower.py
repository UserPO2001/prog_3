# imports -node pytz for the timezonedatabase
import tkinter as tk
from tkinter import ttk
import pytz
from datetime import datetime

class TimeShower(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        label = tk.Label(self, text="Time Shower", font=("Helvetica", 18, "bold"))
        label.pack(side="top", fill="x", pady=20)

        back_button = tk.Button(self, text="Back to Home", command=lambda: controller.show_frame("StartScreen"))
        back_button.pack(pady=10)

        self.capital_cities = {
            'Amsterdam': 'Europe/Amsterdam',
            'London': 'Europe/London',
            'New York': 'America/New_York',
            'Tokyo': 'Asia/Tokyo',
            'Sydney': 'Australia/Sydney',
            'Moscow': 'Europe/Moscow',
            'Beijing': 'Asia/Shanghai',
            'Paris': 'Europe/Paris',
            'Berlin': 'Europe/Berlin',
            'Madrid': 'Europe/Madrid',
            'Rome': 'Europe/Rome'
        }

        self.city_label = tk.Label(self, text="Select a city:")
        self.city_label.pack(pady=5)

        self.city_var = tk.StringVar()
        self.city_menu = ttk.Combobox(self, textvariable=self.city_var)
        self.city_menu['values'] = sorted(list(self.capital_cities.keys()))
        self.city_menu.pack(pady=5)
        self.city_menu.bind("<<ComboboxSelected>>", self.update_clock)

        self.time_label = tk.Label(self, font=("calibri", 40, "bold"), background="purple", foreground="white")
        self.time_label.pack(pady=20)

        self.update_clock()

    def update_clock(self, event=None):
        selected_city = self.city_var.get()
        if selected_city:
            timezone = pytz.timezone(self.capital_cities[selected_city])
        else:
            timezone = pytz.utc

        current_time = datetime.now(timezone).strftime("%Y-%m-%d %H:%M:%S")
        self.time_label.config(text=current_time)
        self.after(1000, self.update_clock)
