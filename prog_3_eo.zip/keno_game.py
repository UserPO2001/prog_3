import tkinter as tk
from tkinter import messagebox
import random

class KenoGame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.setup_ui()

    def setup_ui(self):
        # Title
        label = tk.Label(self, text="Keno Game", font=("Helvetica", 18, "bold"))
        label.grid(row=0, column=0, columnspan=10, pady=20)

        # Instructions
        instructions = tk.Label(self, text="Select 5 numbers between 1 and 70")
        instructions.grid(row=1, column=0, columnspan=10, pady=10)

        # Number selection
        self.selected_numbers = []
        self.number_buttons = []
        for i in range(1, 71):
            button = tk.Button(self, text=str(i), width=4, command=lambda i=i: self.toggle_number(i))
            button.grid(row=(i-1)//10 + 2, column=(i-1)%10, padx=2, pady=2)
            self.number_buttons.append(button)

        # Draw button
        draw_button = tk.Button(self, text="Draw Numbers", command=self.draw_numbers)
        draw_button.grid(row=8, column=0, columnspan=10, pady=10)

        # Results display
        self.result_label = tk.Label(self, text="", font=("Helvetica", 14))
        self.result_label.grid(row=9, column=0, columnspan=10, pady=10)

        # Back to home button
        back_button = tk.Button(self, text="Back to Home", command=lambda: self.controller.show_frame("StartScreen"))
        back_button.grid(row=10, column=0, columnspan=10, pady=10)

    def toggle_number(self, number):
        if number in self.selected_numbers:
            self.selected_numbers.remove(number)
            self.number_buttons[number-1].config(bg="SystemButtonFace")
        else:
            if len(self.selected_numbers) < 5:
                self.selected_numbers.append(number)
                self.number_buttons[number-1].config(bg="lightgreen")
            else:
                messagebox.showwarning("Warning", "You can only select 5 numbers.")

    def draw_numbers(self):
        if len(self.selected_numbers) != 5:
            messagebox.showwarning("Warning", "Please select exactly 5 numbers.")
            return

        drawn_numbers = random.sample(range(1, 71), 5)
        matches = set(drawn_numbers) & set(self.selected_numbers)

        self.result_label.config(
            text=f"Drawn Numbers: {', '.join(map(str, drawn_numbers))}\n"
                 f"Your Numbers: {', '.join(map(str, self.selected_numbers))}\n"
                 f"Matches: {len(matches)}\n"
                 f"Matched Numbers: {', '.join(map(str, matches))}"
        )

        # Reset selection
        self.selected_numbers = []
        for button in self.number_buttons:
            button.config(bg="SystemButtonFace")
